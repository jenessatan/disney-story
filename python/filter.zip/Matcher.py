from fuzzywuzzy import fuzz
import os
import shutil

class Matcher():
    def __init__(self, mainDf, mainCol, lookupDf, lookupCol):
        self.mainDf = mainDf.copy()
        self.mainCol = mainCol
        self.lookupDf = lookupDf
        self.lookupCol = lookupCol

    def doWork(self, threshold=90, toDir="./", fileOut="out.csv"):
        cols = self.__getAllColsFromLookupDf()

        self.mainDf[cols] = self.mainDf[self.mainCol].apply(
            lambda valMainCol: self.__getMatch(valMainCol, cols)
        )

        filePath = self.__setupFilePath(toDir, fileOut)
        self.mainDf = self.mainDf[self.mainDf["score"]>threshold]
        self.mainDf.to_csv(filePath, index=False)
        return self.mainDf

    def __setupFilePath(self, toDir, fileOut):
        if not os.path.isdir(toDir):
            os.makedirs(toDir)
        filePath = os.path.join(toDir, fileOut)
        if os.path.exists(filePath):
            print("File: {} Exists! Copying Old File...".format(filePath))
            self.__copyFile(fromDir=toDir, fileIn=fileOut, toDir=toDir)
            os.remove(filePath)
            print("Removed Old File: {}".format(filePath))
        return filePath

    def __copyFile(self, fromDir, fileIn, toDir):
        fromPath = os.path.join(fromDir, fileIn)
        fileName = fileIn.split(".")[0]
        count = 0
        while 1:
            toNewPath = os.path.join(toDir, "{}_oldCopy_{}.csv".format(fileName, count))
            if not os.path.exists(toNewPath):
                shutil.copyfile(fromPath, toNewPath)
                print("Old File Saved As: {}".format(toNewPath))
                break
            count += 1

    def __getAllColsFromLookupDf(self):
        self.lookupDf["score"] = [0]*self.lookupDf.shape[0]
        return self.lookupDf.columns.tolist()

    def __getFuzzyScore(self, str1, str2):
        return fuzz.token_sort_ratio(str1, str2)
        # return fuzz.token_set_ratio(str1, str2)

    def __getMatch(self, originString, returnCols=[]):
        self.lookupDf["score"] = self.lookupDf[self.lookupCol].apply(
            lambda valLookupCol: self.__getFuzzyScore(valLookupCol, originString)
        )
        # return my_value corresponding to the highest score
        # print(lookupTable["score"])
        return self.lookupDf.loc[self.lookupDf["score"].idxmax(), returnCols]
