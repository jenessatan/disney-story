from Matcher import Matcher
import pandas as pd
import os

awards = pd.read_csv("./data/academy-awards.csv")
movies = pd.read_csv("./data/disney-movies.csv")

is_win = awards["Winner"] == 1
awards = awards[is_win]

awards["Name_Cleaned"] = awards["Name"].apply(lambda row: row.lower().strip())
awards["Film_Cleaned"] = awards["Film"].astype(str).apply(lambda row: row.lower().strip())

movies["Title_Cleaned"] = movies["movie_title"].apply(lambda row: row.lower().strip())

dir_out = "./out"
movies_merged_on_name_file = "movies_merged_on_name.csv"
movies_merged_on_film_file = "movies_merged_on_film.csv"

movies_merged_on_name_path = os.path.join(dir_out, movies_merged_on_name_file)
movies_merged_on_film_path = os.path.join(dir_out, movies_merged_on_film_file)

instance = Matcher(mainDf=awards, mainCol="Name_Cleaned", lookupDf=movies, lookupCol="Title_Cleaned")
movies_merged_on_name = instance.doWork(threshold=90, toDir=dir_out, fileOut=movies_merged_on_name_file)

instance = Matcher(mainDf=awards, mainCol="Film_Cleaned", lookupDf=movies, lookupCol="Title_Cleaned")
movies_merged_on_film = instance.doWork(threshold=90, toDir=dir_out, fileOut=movies_merged_on_film_file)

def compare_year(row):
    return abs(int(row["Year"]) - int(row["release_date"].split("/")[-1])) < 10

movies_merged = pd.concat([movies_merged_on_name, movies_merged_on_film])

is_within_ten_years = movies_merged.apply(compare_year, axis=1)
movies_merged = movies_merged[is_within_ten_years]

def join_text(row):
    return "{year}:{award}".format(year = row["Year"], award = row["Award"])

movies_merged["Award"] = movies_merged.apply(join_text, axis=1)

movies_merged = movies_merged.groupby("Title_Cleaned")["Award"].apply(lambda x: ";".join(x.values)).reset_index()

result = pd.merge(movies, movies_merged, how="left", on="Title_Cleaned").drop(["Title_Cleaned"], axis=1)

result.to_csv("./out/disney-movies-awards.csv", index=False)
